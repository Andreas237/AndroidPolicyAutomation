#!/bin/sh
#set -x
para_pos=$1
sch_ret=$2
ofd=$3
md5_sum=$4
class_f=`echo $sch_ret | cut -d':' -f1`
class_name=`basename $class_f | cut -d'.' -f1 `
lno=`echo $sch_ret | cut -d':' -f2`
line=`echo $sch_ret | cut -d':' -f3`
src_activity=""
tar_activity=""

#find "invoke-"
if [ ! -z "$(echo \"$line\" | grep 'invoke-')" ];then
    src_para=`echo "$line" | sed 's/^.*{\([^,]*\),.*/\1/g'`
    #tar_para=`echo "$line" | sed 's/^.*{[^,]*, \([^}]*\)}.*/\1/g' | cut -d',' -f1 | sed -e 's/^ *//g' -e 's/ *$//g'`
    tar_para=`echo "$line" | sed 's/^.*{\([^}]*\)}.*/\1/g' | cut -d',' -f"$para_pos" | sed -e 's/^ *//g' -e 's/ *$//g'`
    if [ -z "$src_para" -o -z "$tar_para" ];then
        echo "[err] src/tar parameter missing, exit"
        exit
    fi

    #find method
    grep -i -n '.method' $class_f > $ofd/tmp/$class_name.$lno.methods
    pre_lno=0
    method=''
    while read l; do
        c_lno=`echo $l | cut -d':' -f1`
        m=`echo $l | sed '/^[0-9]*:\.method [^ ]* \([^(]*\)(.*$/!d;s//\1/'`
        if [ ! -z "$m" ];then
            method="$m"
        fi
        if [ $lno -ge $pre_lno -a $lno -le $c_lno ];then
            break
        fi
        pre_lno=$c_lno
    done < $ofd/tmp/$class_name.$lno.methods
    if [ -z "$method" ];then
        echo "[err] can not find method name"
    fi
    
    #track source
    if [ ! -z "$(echo $src_para | grep -i '^v')" ];then # V* parameter, local 
        ret=`python $ofd/../code/find_activity_in_local.py $src_para $method $pre_lno $c_lno "$class_f"`
        if [ ! -z "$(echo "$ret" | grep '\[err\]')" ];then
            echo "$ret"
        else
            src_activity=$ret        
        fi
    elif [ ! -z "$(echo $src_para | grep -i '^p')" ];then # P* parameter, 
        if [ "$src_para" == "p0" ];then
            src_activity=$class_name
        fi
    else # unsupported
        echo "[err] unsupported source para:$src_para"
    fi 

    #track target
    if [ ! -z "$(echo $tar_para | grep -i '^v')" ];then # V* parameter, local 
        ret=`python $ofd/../code/find_intent_in_local.py $tar_para $method $pre_lno $c_lno "$class_f"`
        if [ ! -z "$(echo "$ret" | grep '\[err\]')" ];then
            echo $ret
        else
            tar_activity=$ret        
        fi
    elif [ ! -z "$(echo $tar_para | grep -i '^p')" ];then # P* parameter, 
        continue
    else # unsupported
        echo "[err] unsupported target para:$tar_para"
    fi 

    #results
    #echo "[invoke]\n\tline:$line\n\tclass_file:$class_f\n\tclass_name:$class_name\n\tline_num:$lno\n\tsrc_para:$src_para\n\ttar_para:$tar_para\n\tmethod:$method ($pre_lno->$c_lno)"
    #echo "\t[edge]$src_activity ===> $tar_activity"
    echo "$src_activity,$tar_activity,$method" >> $ofd/$md5_sum.edges
fi
