#!/bin/sh
#set -x
dir=/Users/fangfangzhang/Research/smartphone/codes
inf=$1
name=$(basename $inf | sed 's/\.apk//g')
ofd=$name
mkdir -p $dir/$ofd/
if [ -s $inf ];then
    echo "[apk-name]: `basename $inf`"
    t1=`date +%s`
    /usr/local/bin/apktool d -f $inf $dir/$ofd/ 
    t2=`date +%s`
    echo "[apktool-time]:$(($t2-$t1))"
    #for f in `find $dir/$ofd/* -name "*.smali"`; do
    #    echo $f
    #    python $dir/code/analyze.py $f
    #done
    ##########################
    #per function analysis
    cd $dir/$ofd/
    t3=`date +%s`
    while read l;do
        func=`echo $l | cut -d',' -f1`
        para_pos=`echo $l | cut -d',' -f2`
        #echo "\n========checking $func=========="
        grep -i -r -n "\->$func(" ./* > src_ret.tmp
        while read l ;do
            #echo $l
            /bin/sh $dir/code/analyze.sh $para_pos "$l" $dir/analysis $name
        done < src_ret.tmp
    done < $dir/code/func.list
    t4=`date +%s`
    echo "[edges-time]:$(($t4-$t3))"
    if [ -s $dir/analysis/$name.edges ];then
        cat $dir/analysis/$name.edges | sort | uniq > $dir/analysis/$name.t
        mv -f $dir/analysis/$name.t $dir/analysis/$name.edges
    fi   
else
    echo "input file empty?!"
fi
