(1) put all the apks in a dir.
(2) unzip the code.tar to dir/code and change the $dir in dex2smali.sh
(3) mkdir a new directory "analysis" in dir
(4) ./dex2smali.sh your_apk_name

Graph comparison:
./vf.py ../analysis/graph_1.edge ../analysis/graph_2.edge

Can you redirect all the output to a file and send the file to me?
