#!/usr/bin/env python

import sys,re,os

def backward_search_first(pattern, data, current_pos):
    
    return

def get_activity_name(match):
    ret=re.search('/(\w*?activity)', match, re.I)
    if ret:
        return ret.group(1)
    return None

def get_para_list(line):
    plist=[]
    ret=re.search(' \{([^\}]+?)\},', line)
    if ret:
        plist=ret.group(1).split(',')   
    return plist

def find_intent_activity_t1(para, method):
    activity=get_class_activity(para, method)
    if activity: 
        return activity
    pattern="^.+?\W%s\W.+?$" % para
    matchs=re.findall(pattern, method, re.M)
    #print matchs
    if matchs:
        for match in matchs:
            if re.search('activity', match, re.I):
                return get_activity_name(match)
    return None

def get_class_activity(para, method):
    pattern="const-class %s,.*$" %para
    ret=re.search(pattern, method, re.M) 
    if ret:
        return get_activity_name(ret.group(0))        
    return None

def find_intent_activity_t2(para, method):
    pattern="^.+?\W%s\W.+?Intent;->setClass\(.*$" % para
    matchs=re.findall(pattern, method, re.M)
    #print matchs
    if matchs:
        for match in matchs:
            para_list=get_para_list(match)
            activity=get_class_activity(para_list[2].strip(), method)
            if activity: return activity
    pattern="^.+?\W%s\W.+?Intent;->setComponent\(.*$" % para
    matchs=re.findall(pattern, method, re.M)
    #print matchs
    if matchs:
        for match in matchs:
            para_list=get_para_list(match)
            activity=get_class_activity(para_list[2].strip(), method)
            if activity: return activity
    pattern="^.+?\W%s\W.+?Intent;->setAction\(.*$" % para
    matchs=re.findall(pattern, method, re.M)
    #print matchs
    if matchs:
        for match in matchs:
            para_list=get_para_list(match)
            pattern='^.*?const-string %s, "(.*?)"' % para_list[1]
            #print pattern
            ret=re.search(pattern, method, re.M)
            if ret:
                return ret.group(1)
    return None

def find_intent_activity_t3(para, method):
    pattern='^.*?const-string %s, "(.*?)"' % para
    #print pattern
    ret=re.search(pattern, method, re.M)
    if ret:
        return ret.group(1)
    return None

def find_intent_activity_t4(para, method):
    pattern=', [^,]+?\)Landroid/content/Intent;.+?move-result-object %s' % para
    ret=re.search(pattern, method, re.S)
    if ret:
        return get_activity_name(ret.group(0))
    return None

def get_intent_activity_name(match, method):
    para_list=get_para_list(match)
    #print para_list
    if match.find('(Landroid/content/Context;Ljava/lang/Class;)') >= 0: #type 1
        return find_intent_activity_t1(para_list[2].strip(), method)
    if match.find('()V') >= 0: #type 2
        return find_intent_activity_t2(para_list[0].strip(), method)
    if match.find('(Ljava/lang/String;Landroid/net/Uri;)') >= 0: #type 3
        return find_intent_activity_t3(para_list[1].strip(), method)
    if match.find('(Landroid/content/Intent;)') >= 0: #type 4
        return find_intent_activity_t4(para_list[1].strip(), method)
    return None
 
def get_intent_from_method(method, para):
    intent=None
    pattern="^.+? \{%s[,\}].+?/Intent;-><init>\(.*$" % para
    matchs=re.findall(pattern, method, re.M)
    #print matchs
    if matchs:
        for match in matchs:
            intent=get_intent_activity_name(match, method) 
            if intent: return intent
    intent=find_intent_activity_t4(para, method)
    return intent

def main():
    para=str(sys.argv[1]).strip()
    method_name=str(sys.argv[2]).strip()
    start_lno=int(sys.argv[3])
    end_lno=int(sys.argv[4])
    smali_f=None
    try:
        fname=sys.argv[5].strip()
        smali_f=open(fname, 'r')
    except:
        print "[err] can not open %s" % fname
        return
    ct=1
    log=False
    method=""
    for l in smali_f.readlines():
        if ct>=start_lno:
            log=True 
        if ct>end_lno:
            break
        if log:
            method+=l
        ct+=1

    #print method 
    intent=get_intent_from_method(method, para)
    print intent
    return 

if __name__=="__main__":
    main()
