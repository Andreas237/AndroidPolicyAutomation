#!/usr/bin/env python

import sys,re,os


def get_activity_name(match):
    ret=re.search('/(\w*?activity)', match, re.I)
    if ret:
        return ret.group(1)
    return None

def get_activity_from_method(method, para):
    pattern="^.+?\W%s\W.+?$" % para
    matchs=re.findall(pattern, method, re.M)
    #print matchs
    if matchs:
        for match in matchs:
            if re.search('activity', match, re.I):
                return get_activity_name(match) 
    return None

def main():
    para=str(sys.argv[1]).strip()
    method_name=str(sys.argv[2]).strip()
    start_lno=int(sys.argv[3])
    end_lno=int(sys.argv[4])
    smali_f=None
    try:
        fname=sys.argv[5].strip()
        smali_f=open(fname, 'r')
    except:
        print "[err] can not open %s" % fname
        return
    ct=1
    log=False
    method=""
    for l in smali_f.readlines():
        if ct>=start_lno:
            log=True 
        if ct>end_lno:
            break
        if log:
            method+=l
        ct+=1

    #print method 
    activity=get_activity_from_method(method, para)
    print activity
    return 

if __name__=="__main__":
    main()
