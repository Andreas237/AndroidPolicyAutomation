#!/usr/bin/env python

import sys,re,os
import copy
from copy import deepcopy
from itertools import combinations #python 2.6+


def main():
    print "[Apk pair]: ",sys.argv[1],sys.argv[2]
    nodes_1=[]
    nodes_2=[]
    edges_1=[]
    edges_2=[]
    for l in open(sys.argv[1],'r'):
        segs=l.strip().split(',')
        if len(segs) != 3:
            continue
        if len(segs[0])<1 or len(segs[1])<1 or len(segs[2])<1:
            continue
        if segs[0].strip() == "None" or segs[1].strip() == "None":
            continue
        if not segs[0] in nodes_1:
            nodes_1.append(segs[0]);
        index_1 = nodes_1.index(segs[0])
        #print index_1
        if not segs[1] in nodes_1:
            nodes_1.append(segs[1]);
        index_2 = nodes_1.index(segs[1]);
        #print index_2
        edges_1.append([index_1,index_2,segs[2]])
    #print nodes_1
    #print edges_1

    for l in open(sys.argv[2],'r'):
        segs=l.strip().split(',')
        if len(segs) != 3:
            continue
        if len(segs[0])<1 or len(segs[1])<1 or len(segs[2])<1:
            continue
        if segs[0].strip() == "None" or segs[1].strip() == "None":
            continue

        if not segs[0] in nodes_2:
            nodes_2.append(segs[0]);
        index_1 = nodes_2.index(segs[0])
        #print index_1
        if not segs[1] in nodes_2:
            nodes_2.append(segs[1]);
        index_2 = nodes_2.index(segs[1]);
        edges_2.append([index_1,index_2,segs[2]])
   # print nodes_2
   # print edges_2


    if len(edges_1) < 2 or len(edges_2) < 2:
        print "< 2 edges ??"
        return
    print "%d real edges in %s" % (len(edges_1), sys.argv[1])
    print "%d real edges in %s" % (len(edges_2), sys.argv[2])
   
#    threshold = 0.8; 
 
    if len(nodes_1)<len(nodes_2):
        vf(nodes_1, edges_1, nodes_2, edges_2)#, threshold)    
    else:
        vf(nodes_2, edges_2, nodes_1, edges_1)#, threshold)




def vf(nodes_1, edges_1, nodes_2, edges_2):#, threshold):
    
    core_1 = [-1] * len(nodes_1);
    core_2 = [-1] * len(nodes_2);
    in_1 = [-1]* len(nodes_1);
    out_1 = [-1] * len(nodes_1);
    in_2 = [-1]* len(nodes_2);
    out_2 = [-1] * len(nodes_2);
    
    state = [core_1, core_2, in_1, out_1, in_2, out_2]

    #match(nodes_1,edges_1,nodes_2,edges_2,state,threshold);

    for i in range(0, len(core_1)):
        match_no = match(nodes_1,edges_1,nodes_2,edges_2,state,i);
        if match_no != -1:                    
            print "Match Nodes: ", match_no, "Score: ", float(match_no)/len(nodes_1);
            break;

def match(nodes_1,edges_1,nodes_2,edges_2,state, tolerate):
    match_no = len(nodes_1) - state[0].count(-1)
    if match_no >= len(nodes_1) - tolerate:
        print "[ALL Match No]: ", match_no, state[0]
        #delete isolated node
        temp_core = copy.deepcopy(state[0]) 
        for j in range(0,len(nodes_1)):
                if temp_core[j]!= -1:
                    tag = 0;
                    for e in edges_1:
                        if e[0] == j and state[0][e[1]]!= -1:
                            tag = 1;
                            #print e, e[0], e[1], state[0][e[1]]
                            break;
                        if e[1] == j and state[0][e[0]]!= -1:
                            tag = 1;
                            #print e, e[0], state[0][e[0]]
                            break;
                    if tag == 0:
                        match_no = match_no - 1
                        temp_core[j] = -1
        print "[Remove Isolated Node]: ", match_no, temp_core
        return match_no;
    else:
        pairs = P(nodes_1,edges_1,nodes_2,edges_2,state) 
        for pair in pairs:
            if feasibility_check(pair[0], pair[1],nodes_1,edges_1,nodes_2,edges_2,state):
                new_state = copy.deepcopy(state)
                new_state = update_state(pair[0],pair[1],nodes_1,edges_1,nodes_2,edges_2,new_state)
                match_no = match(nodes_1,edges_1,nodes_2,edges_2, new_state, tolerate)
                if match_no >= 0:
                    return match_no
                #state = copy.deepcopy(old_state)
                #restore_state(pair[0],pair[1],nodes_1,edges_1,nodes_2,edges_2,state)
        return -1;   

def P(nodes_1,edges_1,nodes_2,edges_2,state):
    core_1 = state[0]
    core_2 = state[1]
    in_1 = state[2]
    out_1 = state[3]
    in_2 = state[4]
    out_2 = state[5]
    #print "in P", out_1, out_2
    pairs = [];
    for i in range(0, len(out_1)):
        if out_1[i] != -1:
            for j in range(0,len(out_2)):
                if out_2[j] != -1:
                    pairs.append([i,j]);
            #break;            
 
    if len(pairs)!=0:
        return pairs 

    for i in range(0, len(in_1)):
        if in_1[i] != -1:
            for j in range(0,len(in_2)):
                if in_2[j] != -1:
                    pairs.append([i,j]);
            #break;
    if len(pairs)!=0:
        return pairs

    for i in range(0, len(core_1)):
        if core_1[i] == -1 and in_1[i] == -1 and out_1[i] == -1:
            for j in range(0, len(core_2)):
                if core_2[j] == -1 and in_2[j] == -1 and out_2[j] == -1:
                    pairs.append([i,j]);
            #break;
    return pairs;          
 

def feasibility_check(p1, p2, nodes_1,edges_1,nodes_2,edges_2,state):
    core_1 = state[0]
    core_2 = state[1]
    in_1 = state[2]
    out_1 = state[3]
    in_2 = state[4]
    out_2 = state[5]

    for e in edges_1:
        #print "e:" , e[0],  e[1],  e[2]
        #R_succ
        if e[0] == p1 and core_1[e[1]]!=-1:
            m = core_1[e[1]] # edge: <p2, m>
            if not [p2, m, e[2]] in edges_2:
                return False
        #R_pre        
        if e[1] == p1 and core_1[e[0]]!= -1:
            n = core_1[e[0]] # edge: <n, p2>
            if not [n, p2, e[2]] in edges_2:
                return False

    
    for e in edges_2:
        #print "e:" , e[0],  e[1],  e[2]
        #R_succ
        if e[0] == p2 and core_2[e[1]]!= -1:
            m = core_2[e[1]]
            if not [p1, m, e[2]] in edges_1:
                return False

        #R_pre
        if e[1] == p2 and core_2[e[0]]!= -1:
            n = core_2[e[0]]
            if not [n, p1, e[2]] in edges_1:
                return False


    #R_termin

    #R_termout


    #R_new
    return True

def update_state(p1, p2, nodes_1,edges_1,nodes_2,edges_2,state):
    
    core_1 = state[0]
    core_2 = state[1]
    in_1 = state[2]
    out_1 = state[3]
    in_2 = state[4]
    out_2 = state[5]

    
    core_1[p1] = p2
    core_2[p2] = p1
    
    in_1[p1] = -1;
    out_1[p1] = -1;
    for e in edges_1:
        if e[0] == p1 and core_1[e[1]] == -1:
           out_1[e[1]] = 1; 
        if e[1] == p1 and core_1[e[0]] == -1:
           in_1[e[0]] = 1;    

    in_2[p2] = -1;
    out_2[p2] = -1;
    for e in edges_2:
        if e[0] == p2 and core_2[e[1]] == -1:
            out_2[e[1]] = 1;
        if e[1] == p2 and core_2[e[0]] == -1:
            in_2[e[0]] = 1;

    state = [core_1, core_2, in_1, out_1, in_2, out_2]
    return state;
    #return

def restore_state(p1, p2, nodes_1,edges_1,nodes_2,edges_2,state):

    core_1 = state[0]
    core_2 = state[1]
    in_1 = state[2]
    out_1 = state[3]
    in_2 = state[4]
    out_2 = state[5]


    core_1[p1] = -1
    core_2[p2] = -1

    for i in range(0,len(core_1)):
        in_1[i]= -1
        out_1[i]=-1

    for i in range(0, len(core_2)):
        in_2[i] = -1
        out_2[i] = -1

    for i in range(0,len(core_1)):
        if core_1[i]!= -1:
            for e in edges_1:
                if e[0] == nodes_1[i] and core_1[e[1]] == -1:
                    out_1[e[1]] = 1; 
                if e[1] == nodes_1[i] and core_1[e[0]] == -1:
                    in_1[e[0]] = 1;    

    for i in range(0, len(core_2)):
        if core_2[i]!= -1:
            for e in edges_2:
                if e[0] == nodes_2[i] and core_2[e[1]] == -1:
                    out_2[e[1]] = 1;
                if e[1] == nodes_2[i] and core_2[e[0]] == -1:
                    in_2[e[0]] = 1;

    #new_state = [core_1, core_2, in_1, out_1, in_2, out_2]
    #return new_state;
    return

"""    #pair-wise compare
    sg1.sort(key=lambda s:len(s), reverse=True)
    #print '\n'.join(str(x) for x in sg1)
    sg2.sort(key=lambda s:len(s), reverse=True)
    #print '\n'.join(str(x) for x in sg2)
    for i in sg1:
        for j in sg2:
            if len(j)==len(i):
                comm=compare_subgraph(i,j)
                if comm:
                    print "MCS found between:"
                    print '\n'.join(str(x) for x in i)
                    print "--------AND---------"
                    print '\n'.join(str(x) for x in j)
                    return
            if len(j)<len(i):
                break
    return
"""

if __name__=="__main__":
    main()
